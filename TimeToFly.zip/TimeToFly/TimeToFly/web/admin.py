from django.contrib import admin
from TimeToFly.web.models import Flight, Passenger, Town


admin.site.register(Flight)
admin.site.register(Passenger)
admin.site.register(Town)